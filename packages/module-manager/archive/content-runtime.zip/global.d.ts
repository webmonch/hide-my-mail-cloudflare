declare module '*?inline' {
  const src: string;
  export default src;
}
